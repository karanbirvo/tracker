<?php
require_once 'includes/functions.php';
requireLogin();

// Admin Access Check
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    $_SESSION['message'] = "Access Denied."; $_SESSION['message_type'] = "danger"; header("Location: index.php"); exit();
}

// Fetch all email history, joining with users table
$stmt = $pdo->query("SELECT el.*, u.username FROM email_logs el JOIN users u ON el.user_id = u.id ORDER BY el.sent_at DESC");
$logs = $stmt->fetchAll();
require_once 'includes/header.php';
?>

<!-- === CSS FOR THE MODAL (POPUP) - Copied from my_email_history.php === -->
<style>
    .modal-backdrop { display: none; position: fixed; z-index: 1050; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0,0,0,0.6); animation: fadeIn 0.3s; }
    .modal-content-area { background-color: #fefefe; margin: 5% auto; padding: 25px; border: 1px solid #888; width: 80%; max-width: 800px; border-radius: 8px; position: relative; box-shadow: 0 5px 15px rgba(0,0,0,0.3); animation: slideIn 0.3s; }
    .modal-close-btn { color: #aaa; position: absolute; top: 10px; right: 20px; font-size: 28px; font-weight: bold; transition: color 0.2s; }
    .modal-close-btn:hover, .modal-close-btn:focus { color: black; text-decoration: none; cursor: pointer; }
    .modal-body { max-height: 60vh; overflow-y: auto; padding-right: 15px; }
    @keyframes fadeIn { from {opacity: 0;} to {opacity: 1;} }
    @keyframes slideIn { from {transform: translateY(-50px);} to {transform: translateY(0);} }
</style>

<h1><i class="fas fa-server"></i> Admin - All Sent Email Logs</h1>

<div class="card" style="margin-top: 20px;">
    <?php if (empty($logs)): ?>
        <p class="alert alert-info">No emails have been sent by any user yet.</p>
    <?php else: ?>
        <table class="reports-table">
            <thead>
                <tr>
                    <th>Date & Time</th>
                    <th>Sender</th>
                    <th>To</th>
                    <th>Subject</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($logs as $log): ?>
                <tr>
                    <td><?= htmlspecialchars(date('Y-m-d H:i:s', strtotime($log['sent_at']))) ?></td>
                    <td><?= htmlspecialchars($log['username']) ?></td>
                    <td><?= htmlspecialchars($log['sent_to']) ?></td>
                    <td><?= htmlspecialchars($log['subject']) ?></td>
                    <td>
                        <?php if ($log['status'] === 'success'): ?> <span style="color: green; font-weight: bold;">Success</span> <?php else: ?> <span style="color: red; font-weight: bold;">Failed</span> <?php endif; ?>
                    </td>
                    <td>
                        <button class="button-link view-details-btn" 
                                data-to="<?= htmlspecialchars($log['sent_to']) ?>"
                                data-from="<?= htmlspecialchars($log['sent_from']) ?>"
                                data-subject="<?= htmlspecialchars($log['subject']) ?>"
                                data-attachments="<?= !empty($log['attachments']) ? htmlspecialchars($log['attachments']) : 'None' ?>"
                                data-error="<?= htmlspecialchars($log['error_message']) ?>">
                            <i class="fas fa-eye"></i> View Details
                        </button>
                        <div class="log-body-content" style="display: none;"><?= $log['body'] ?></div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<!-- === THE MODAL HTML STRUCTURE - Copied from my_email_history.php === -->
<div id="details-modal" class="modal-backdrop">
    <div class="modal-content-area">
        <span id="modal-close-btn" class="modal-close-btn">&times;</span>
        <h2 id="modal-subject">Email Details</h2>
        <hr>
        <div class="modal-body">
            <p><strong>From:</strong> <span id="modal-from"></span></p>
            <p><strong>To:</strong> <span id="modal-to"></span></p>
            <p><strong>Attachments:</strong> <span id="modal-attachments"></span></p>
            <div id="modal-error-section" style="display: none;">
                <p><strong>Error Message:</strong></p>
                <pre id="modal-error" style="color: red; white-space: pre-wrap; background: #f9f9f9; padding: 10px; border-radius: 4px;"></pre>
            </div>
            <hr>
            <h3>Email Body:</h3>
            <div id="modal-body-content" style="border: 1px solid #ddd; padding: 15px; border-radius: 4px; background: #fff;"></div>
        </div>
    </div>
</div>

<!-- === JAVASCRIPT FOR MODAL FUNCTIONALITY - Copied from my_email_history.php === -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const modal=document.getElementById('details-modal'),closeBtn=document.getElementById('modal-close-btn'),modalSubject=document.getElementById('modal-subject'),modalFrom=document.getElementById('modal-from'),modalTo=document.getElementById('modal-to'),modalAttachments=document.getElementById('modal-attachments'),modalErrorSection=document.getElementById('modal-error-section'),modalError=document.getElementById('modal-error'),modalBodyContent=document.getElementById('modal-body-content'),detailButtons=document.querySelectorAll('.view-details-btn');detailButtons.forEach(button=>{button.addEventListener('click',function(){const from=this.dataset.from,to=this.dataset.to,subject=this.dataset.subject,attachments=this.dataset.attachments,error=this.dataset.error,bodyHtml=this.closest('td').querySelector('.log-body-content').innerHTML;modalSubject.textContent=subject;modalFrom.textContent=from;modalTo.textContent=to;modalAttachments.textContent=attachments;modalBodyContent.innerHTML=bodyHtml;if(error){modalError.textContent=error;modalErrorSection.style.display='block';}else{modalErrorSection.style.display='none';}modal.style.display='block';});});function closeModal(){modal.style.display='none';}closeBtn.addEventListener('click',closeModal);modal.addEventListener('click',function(event){if(event.target===modal){closeModal();}});document.addEventListener('keydown',function(event){if(event.key==="Escape"&&modal.style.display==='block'){closeModal();}});
});
</script>

<?php require_once 'includes/footer.php'; ?>