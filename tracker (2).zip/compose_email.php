<?php
// ... [The entire PHP block at the top of your file remains exactly the same] ...
require_once 'includes/functions.php';

requireLogin();
$userId = (int)($_GET['user_id'] ?? $_SESSION['user_id']);
$dateFrom = $_GET['date_from'] ?? date('Y-m-d');
$timeFrom = $_GET['time_from'] ?? '00:00:00';
$dateTo = $_GET['date_to'] ?? $dateFrom;
$timeTo = $_GET['time_to'] ?? '23:59:59';
$stmt = $pdo->prepare("SELECT task_name, start_time, end_time FROM time_entries WHERE user_id = :user_id AND start_time >= :start_datetime AND start_time <= :end_datetime ORDER BY start_time ASC");
$stmt->execute(['user_id' => $userId, 'start_datetime' => "$dateFrom $timeFrom", 'end_datetime' => "$dateTo $timeTo"]);
$entries = $stmt->fetchAll();
$tasks_list = "";
if (empty($entries)) { $tasks_list = "<li>No tasks logged for this period.</li>"; } 
else { foreach ($entries as $entry) {
    $durationStr = "(Ongoing)";
    if ($entry['end_time']) { $start = new DateTime($entry['start_time']); $end = new DateTime($entry['end_time']); $interval = $start->diff($end); $durationStr = sprintf('(%02dh %02dm %02ds)', $interval->h, $interval->i, $interval->s); }
    $tasks_list .= "<li>" . htmlspecialchars($entry['task_name']) . " " . $durationStr . "</li>\n";
}}
$default_email_body = "Hi Team,\n\nPlease find my End of Day (EOD) report below.\n\n<b>Tasks Performed:</b>\n<ul>\n" . $tasks_list . "</ul>\n\nPlease let me know if you have any questions.\n\nThank you,\n" . htmlspecialchars($_SESSION['username']);
$default_email_body_html = nl2br(trim($default_email_body));
$subject = "EOD Report: " . htmlspecialchars($_SESSION['username']) . " - " . date('F j, Y', strtotime($dateFrom));
$stmtSettings = $pdo->prepare("SELECT default_recipients, smtp_username FROM users WHERE id = ?");
$stmtSettings->execute([$_SESSION['user_id']]);
$settings = $stmtSettings->fetch();
$defaultRecipients = decrypt_data($settings['default_recipients'] ?? '');
$fromEmail = decrypt_data($settings['smtp_username'] ?? 'Not Configured');
require_once 'includes/header.php';
?>

<!-- Include TinyMCE. Replace with your actual API key. -->
<script src="https://cdn.tiny.cloud/1/n0wu92kefc4epvtdbx3gtl1yfw5oykhgc341ncwvosakbjdz/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>

<h1><i class="fas fa-paper-plane"></i> Compose & Send EOD Report</h1>

<?php if ($fromEmail === 'Not Configured' || empty($fromEmail)): ?>
    <div class="alert alert-danger">Your SMTP settings are not configured. <a href="email_settings.php" class="alert-link">Please configure them now</a>.</div>
<?php else: ?>
    <div class="card" style="padding:25px;">
        <form id="email-compose-form" action="actions/send_email.php" method="POST" enctype="multipart/form-data">
            
            <div class="form-group"><label for="to_email">To:</label><input type="text" id="to_email" name="to_email" class="form-control" value="<?= htmlspecialchars($defaultRecipients) ?>" required></div>
            <div class="form-group"><label for="subject">Subject:</label><input type="text" id="subject" name="subject" class="form-control" value="<?= htmlspecialchars($subject) ?>" required></div>
            
            <div class="form-group">
                <label for="email_body">Body:</label>
                <div style="display: flex; flex-wrap: wrap; align-items: center; gap: 15px; margin-bottom: 10px;">
                    <button type="button" id="regenerate-btn" class="button"><i class="fas fa-magic"></i> Regenerate with AI</button>
                    <span id="ai-status" style="font-style: italic; color: #555;"></span>
                </div>
                <textarea id="email_body" name="email_body"><?= htmlspecialchars($default_email_body_html) ?></textarea>
            </div>

            <div class="form-group" style="margin-top: 20px;">
                <label for="attachments">Add Attachments (for "Send via Server" only):</label>
                <input type="file" id="attachments" name="attachments[]" class="form-control" multiple>
            </div>
            
            <div style="margin-top:25px; display: flex; flex-wrap: wrap; gap: 15px; align-items: center; border-top: 1px solid #eee; padding-top: 20px;">
                <button type="submit" class="button button-primary" title="Send using the application's configured SMTP server. This will be logged."><i class="fas fa-server"></i> Send via Server</button>
                <button type="button" id="outlook-btn" class="button secondary" title="Open in your computer's default email app (e.g., Outlook Desktop). Body will be plain text."><i class="fab fa-windows"></i> Open in Desktop App</button>
                <button type="button" id="outlook-web-btn" class="button secondary" title="Opens Outlook Web with plain text and copies the formatted version for you to paste."><i class="fas fa-globe"></i> Open in Outlook Web</button>
            </div>
            
        </form>
    </div>
<?php endif; ?>

<!-- ======================================================== -->
<!-- === COMPLETE & CORRECTED JAVASCRIPT BLOCK ================ -->
<!-- ======================================================== -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // --- TinyMCE Initialization ---
    tinymce.init({
        selector: 'textarea#email_body',
        height: 500,
        plugins: 'preview importcss searchreplace autolink autosave save directionality code visualblocks visualchars fullscreen image link media template codesample table charmap pagebreak nonbreaking anchor insertdatetime advlist lists wordcount help charmap quickbars emoticons',
        toolbar: 'undo redo | bold italic underline strikethrough | fontfamily fontsize blocks | alignleft aligncenter alignright alignjustify | outdent indent |  numlist bullist | forecolor backcolor removeformat | table image link | preview fullscreen',
    });

    // --- AI BUTTON LOGIC ---
    const regenerateBtn = document.getElementById('regenerate-btn');
    const statusDiv = document.getElementById('ai-status');
    regenerateBtn.addEventListener('click', () => {
        const currentContent = tinymce.get('email_body').getContent({ format: 'text' });
        statusDiv.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Asking AI to improve the text...';
        regenerateBtn.disabled = true;
        fetch('actions/regenerate_summary.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'report_data=' + encodeURIComponent(currentContent)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                tinymce.get('email_body').setContent(data.summary);
                statusDiv.innerHTML = '<i class="fas fa-check-circle" style="color: green;"></i> Summary updated by AI.';
            } else {
                statusDiv.innerHTML = `<i class="fas fa-exclamation-triangle" style="color: red;"></i> Error: ${data.message}`;
            }
        })
        .finally(() => { regenerateBtn.disabled = false; });
    });

    // --- DESKTOP APP (MAILTO) BUTTON LOGIC ---
    const outlookBtn = document.getElementById('outlook-btn');
    outlookBtn.addEventListener('click', function() {
        const to = document.getElementById('to_email').value;
        const subject = document.getElementById('subject').value;
        const body = tinymce.get('email_body').getContent({ format: 'text' });
        const mailtoLink = `mailto:${to}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
        window.location.href = mailtoLink;
    });

    // =========================================================================
    // === "COPY AND OPEN" LOGIC FOR OUTLOOK WEB (FINAL AUTOMATED VERSION) =====
    // =========================================================================
    const outlookWebBtn = document.getElementById('outlook-web-btn');
    outlookWebBtn.addEventListener('click', function() {
        const to = document.getElementById('to_email').value;
        const subject = document.getElementById('subject').value;
        
        // Step 1: Get BOTH versions of the content
        const bodyHtml = tinymce.get('email_body').getContent(); 
        const bodyText = tinymce.get('email_body').getContent({ format: 'text' }); 

        // Step 2: Copy the RICH HTML version to the clipboard
        try {
            const blob = new Blob([bodyHtml], { type: 'text/html' });
            const data = [new ClipboardItem({ 'text/html': blob })];
            
            navigator.clipboard.write(data).then(
                () => { // Success callback
                    // Step 3: Now that copy is successful, open the new tab.
                    // The URL will contain the PLAIN TEXT version as a fallback.
                    const baseUrl = 'https://outlook.office.com/mail/deeplink/compose';
                    const outlookUrl = `${baseUrl}?to=${encodeURIComponent(to)}&subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(bodyText)}`;

                    // Step 4: Provide clear feedback to the user
                    const originalText = outlookWebBtn.innerHTML;
                    outlookWebBtn.innerHTML = '<i class="fas fa-check"></i> Copied! Paste to format.';
                    
                    // Step 5: Open Outlook Web in a new tab
                    window.open(outlookUrl, '_blank');

                    // Step 6: Reset the button text after a few seconds
                    setTimeout(() => {
                        outlookWebBtn.innerHTML = originalText;
                    }, 3500);
                },
                () => { // Failure callback
                    alert('Automatic copy failed. The Outlook tab will open with plain text only.');
                    // Still open the tab, but just with plain text
                    const baseUrl = 'https://outlook.office.com/mail/deeplink/compose';
                    const outlookUrl = `${baseUrl}?to=${encodeURIComponent(to)}&subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(bodyText)}`;
                    window.open(outlookUrl, '_blank');
                }
            );
        } catch (e) {
            console.error('Clipboard API failed. This browser may be unsupported.', e);
            alert('Automatic copy is not supported by your browser. The Outlook tab will open with plain text only.');
            // Still open the tab as a fallback
            const baseUrl = 'https://outlook.office.com/mail/deeplink/compose';
            const outlookUrl = `${baseUrl}?to=${encodeURIComponent(to)}&subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(bodyText)}`;
            window.open(outlookUrl, '_blank');
        }
    });
});
</script>

<?php require_once 'includes/footer.php'; ?>