<?php
require_once 'includes/functions.php';
requireLogin();


$userId = $_SESSION['user_id'];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // We encrypt all the new data before saving
    $stmt = $pdo->prepare("UPDATE users SET 
        smtp_host = :smtp_host, 
        smtp_port = :smtp_port, 
        smtp_username = :smtp_username, 
        smtp_password = :smtp_password, 
        default_recipients = :default_recipients,
        email_sender_name = :sender_name,  -- New Field
        email_reply_to = :reply_to         -- New Field
        WHERE id = :user_id");
    
    $stmt->execute([
        'smtp_host' => encrypt_data(trim($_POST['smtp_host'])),
        'smtp_port' => encrypt_data(trim($_POST['smtp_port'])),
        'smtp_username' => encrypt_data(trim($_POST['smtp_username'])),
        'smtp_password' => !empty($_POST['smtp_password']) ? encrypt_data($_POST['smtp_password']) : $_POST['current_password_encrypted'],
        'default_recipients' => encrypt_data(trim($_POST['default_recipients'])),
        'sender_name' => encrypt_data(trim($_POST['email_sender_name'])), // Encrypt new field
        'reply_to' => encrypt_data(trim($_POST['email_reply_to'])),    // Encrypt new field
        'user_id' => $userId
    ]);

    $_SESSION['message'] = "Email settings saved successfully.";
    $_SESSION['message_type'] = "success";
    header("Location: email_settings.php");
    exit();
}

// Fetch all current settings
$stmt = $pdo->prepare("SELECT smtp_host, smtp_port, smtp_username, smtp_password, default_recipients, email_sender_name, email_reply_to FROM users WHERE id = ?");
$stmt->execute([$userId]);
$userSettings = $stmt->fetch();

// Decrypt all data for display
$decrypted_host = decrypt_data($userSettings['smtp_host'] ?? '');
$decrypted_port = decrypt_data($userSettings['smtp_port'] ?? '');
$decrypted_username = decrypt_data($userSettings['smtp_username'] ?? '');
$decrypted_recipients = decrypt_data($userSettings['default_recipients'] ?? '');
$decrypted_sender_name = decrypt_data($userSettings['email_sender_name'] ?? ''); // Decrypt new field
$decrypted_reply_to = decrypt_data($userSettings['email_reply_to'] ?? '');       // Decrypt new field
$password_is_set = !empty($userSettings['smtp_password']);
require_once 'includes/header.php';
?>

<h1><i class="fas fa-envelope-cog"></i> Email & SMTP Settings</h1>
<p>Configure your outgoing email server and sending preferences.</p>

<div class="card" style="max-width: 700px; padding: 25px; margin-top: 20px;">
    <form action="email_settings.php" method="POST">
        
        <h2 style="border-bottom: 1px solid #eee; padding-bottom: 10px;">Sender Identity</h2>
        <div class="form-group">
            <label for="email_sender_name">Your Sender Name:</label>
            <input type="text" name="email_sender_name" id="email_sender_name" class="form-control" value="<?= htmlspecialchars($decrypted_sender_name) ?>" placeholder="e.g., Karanbir Singh from VirtualOplossing">
            <small>This is the name recipients will see. If blank, your username will be used.</small>
        </div>
        <div class="form-group">
            <label for="email_reply_to">"Reply-To" Email Address:</label>
            <input type="email" name="email_reply_to" id="email_reply_to" class="form-control" value="<?= htmlspecialchars($decrypted_reply_to) ?>" placeholder="e.g., your.manager@example.com">
            <small>When a recipient clicks "Reply", their email will go to this address. If blank, it will go to your "From" address.</small>
        </div>

        <h2 style="margin-top: 30px; border-bottom: 1px solid #eee; padding-bottom: 10px;">SMTP Server Configuration</h2>
        <div class="form-group">
            <label for="smtp_host">SMTP Host:</label>
            <input type="text" name="smtp_host" id="smtp_host" class="form-control" value="<?= htmlspecialchars($decrypted_host) ?>" required>
        </div>
        <div class="form-group">
            <label for="smtp_port">SMTP Port:</label>
            <input type="number" name="smtp_port" id="smtp_port" class="form-control" value="<?= htmlspecialchars($decrypted_port) ?>" required>
        </div>
        <div class="form-group">
            <label for="smtp_username">SMTP Username ("From" Address):</label>
            <input type="email" name="smtp_username" id="smtp_username" class="form-control" value="<?= htmlspecialchars($decrypted_username) ?>" required>
        </div>
        <div class="form-group">
            <label for="smtp_password">SMTP Password:</label>
            <input type="password" name="smtp_password" id="smtp_password" class="form-control" placeholder="<?= $password_is_set ? 'Enter new password to change' : 'Enter password' ?>">
            <small>Leave blank to keep your current saved password.</small>
            <input type="hidden" name="current_password_encrypted" value="<?= htmlspecialchars($userSettings['smtp_password'] ?? '') ?>">
        </div>

        <h2 style="margin-top: 30px; border-bottom: 1px solid #eee; padding-bottom: 10px;">Default Recipients</h2>
        <div class="form-group">
            <label for="default_recipients">Default "To" Addresses (comma-separated):</label>
            <textarea name="default_recipients" id="default_recipients" class="form-control" rows="3"><?= htmlspecialchars($decrypted_recipients) ?></textarea>
        </div>
        
        <div style="margin-top: 25px;">
            <button type="submit" class="button button-primary"><i class="fas fa-save"></i> Save Settings</button>
        </div>
    </form>
</div>

<?php require_once 'includes/footer.php'; ?>