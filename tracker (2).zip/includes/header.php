<?php
// Use __DIR__ for robust path resolution relative to the current file (header.php)
require_once __DIR__ . '/db.php';         // For database connection and session_start
require_once __DIR__ . '/functions.php'; // For helper functions like isLoggedIn()

// --- Logic for Active Dropdown States ---
$current_page = basename($_SERVER['PHP_SELF']);

// Pages that belong to the "Admin" dropdown
$admin_pages = ['admin_reports.php', 'admin_users.php', 'admin_email_logs.php'];
$is_admin_page = in_array($current_page, $admin_pages);

// Pages that belong to the "Settings" dropdown
$settings_pages = ['email_settings.php', 'email_layout_settings.php'];
$is_settings_page = in_array($current_page, $settings_pages);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VO TimeTracker</title>
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Google Fonts - Poppins (Example) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <!-- Link to your external style.css for other page content -->
    <link rel="stylesheet" href="css/style.css">

    <!-- =================================================================== -->
    <!-- === CSS FOR RESPONSIVE HEADER AND DROPDOWNS (Added directly here) === -->
    <!-- =================================================================== -->
    <style>
        /* --- Dropdown Menu Styles for Desktop --- */
        .site-navigation li.nav-item-dropdown {
            position: relative;
        }

        .dropdown-arrow {
            font-size: 0.8em;
            margin-left: 5px;
            transition: transform 0.2s ease-in-out;
        }

        .dropdown-menu {
            display: none;
            position: absolute;
            top: 100%;
            left: 0;
            background-color: #ffffff;
            min-width: 240px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.15);
            border-radius: 0 0 8px 8px;
            list-style: none;
            padding: 10px 0;
            margin: 0;
            z-index: 1001;
            border-top: 3px solid #2D5A95; /* Header logo color */
        }

        .nav-item-dropdown:hover .dropdown-menu {
            display: block;
        }

        .nav-item-dropdown:hover .dropdown-arrow {
            transform: rotate(180deg);
        }

        .dropdown-menu li {
            margin-left: 0;
            width: 100%;
        }

        .dropdown-menu li a {
            padding: 12px 20px;
            display: block;
            width: 100%;
            box-sizing: border-box;
            border-radius: 0;
            color: #333; /* Header text color */
            font-weight: 500;
        }

        .dropdown-menu li a:hover {
            background-color: #f0f3f5;
            color: #2D5A95; /* Header logo color */
        }

        /* --- Responsive Styles for Mobile & Tablet --- */
        @media (max-width: 1024px) {
            .header-center-content {
                display: none; /* Hide the clock on smaller screens to make space */
            }
        }
        
        @media (max-width: 992px) {
            .menu-toggle {
                display: flex; /* Show the hamburger icon */
            }

            .site-navigation ul.nav-links {
                display: none; /* Hide the normal navigation links */
                flex-direction: column;
                position: absolute;
                top: 70px; /* Height of the header */
                left: 0;
                width: 100%;
                background-color: #f8f9fa; /* A slightly off-white for the mobile menu */
                box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            }

            .site-navigation ul.nav-links.active {
                display: flex; /* Show the mobile menu when active */
            }

            .site-navigation li {
                width: 100%;
                margin-left: 0;
            }

            .site-navigation li a {
                padding: 15px 20px;
                border-bottom: 1px solid #dde1e6;
                justify-content: flex-start;
            }
            
            /* --- Mobile Dropdown Styles --- */
            .site-navigation li.nav-item-dropdown .dropdown-menu {
                display: block; /* Always show dropdown content in mobile */
                position: static; /* No absolute positioning */
                box-shadow: none;
                border: none;
                min-width: 100%;
                padding: 0;
                background-color: #e9ecef; /* Slightly darker to show hierarchy */
            }

            .nav-item-dropdown > a {
                background-color: #f0f3f5; /* Make the parent link visually distinct */
            }
            
            .nav-item-dropdown:hover .dropdown-arrow {
                transform: none; /* Disable arrow rotation on mobile */
            }
            
            .dropdown-menu li a {
                padding-left: 40px; /* Indent the sub-menu items */
                font-size: 0.9rem;
            }
        }
    </style>
    <!-- =================================================================== -->
    <!-- === END OF CSS BLOCK ============================================== -->
    <!-- =================================================================== -->

   <script>setInterval(function() {
    fetch('/keepalive.php');
},5 * 60 * 1000); // every 5 minutes
</script> 
</head>
<body>
    <header class="site-header">
        <div class="header-container">
            <a href="index.php" class="site-logo">
                <i class="fas fa-clock"></i> VO TimeTracker
            </a>

            <div class="header-center-content">
                <div id="current-time-display" class="current-time">
                    <i class="far fa-clock"></i> <span id="time-now">Loading...</span>
                </div>
            </div>

            <nav class="site-navigation">
                <button class="menu-toggle" id="menu-toggle" aria-label="Toggle Menu" aria-expanded="false">
                    <i class="fas fa-bars"></i>
                    <i class="fas fa-times"></i>
                </button>
                
                <!-- =========== FINALIZED & ORGANIZED MENU AREA =========== -->
                <ul class="nav-links" id="nav-links">
                    <?php if (isLoggedIn()): ?>
                        <li><a href="index.php" class="<?= ($current_page == 'index.php' ? 'active' : '') ?>"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                        <li><a href="reports.php" class="<?= ($current_page == 'reports.php' ? 'active' : '') ?>"><i class="fas fa-chart-bar"></i> My Reports</a></li>
                        <li><a href="my_email_history.php" class="<?= ($current_page == 'my_email_history.php' ? 'active' : '') ?>"><i class="fas fa-history"></i> My Email History</a></li>

                        <?php if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin'): ?>
                            <!-- Admin Dropdown Menu -->
                            <li class="nav-item-dropdown">
                                <a href="#" class="<?= ($is_admin_page ? 'active' : '') ?>">
                                    <i class="fas fa-user-shield"></i> Admin <i class="fas fa-angle-down dropdown-arrow"></i>
                                </a>
                                <ul class="dropdown-menu">
                                    <li><a href="admin_reports.php">Admin Reports</a></li>
                                    <li><a href="admin_users.php">Manage Users</a></li>
                                    <li><a href="admin_email_logs.php">All Email Logs</a></li>
                                </ul>
                            </li>
                        <?php endif; ?>
                        
                        <!-- Settings Dropdown Menu (for all logged-in users) -->
                        <li class="nav-item-dropdown">
                            <a href="#" class="<?= ($is_settings_page ? 'active' : '') ?>">
                                <i class="fas fa-cog"></i> Settings <i class="fas fa-angle-down dropdown-arrow"></i>
                            </a>
                            <ul class="dropdown-menu">
                                  <li><a href="profile.php">My Profile</a></li>
                                <li><a href="email_settings.php">Email SMTP Settings</a></li>
                                <li><a href="email_layout_settings.php">Email Layout & Signature</a></li>
                                <li><a href="ai_history.php">AI Response History</a></li>
                            </ul>
                        </li>

                        <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout (<?= htmlspecialchars($_SESSION['username']) ?>)</a></li>
                    <?php else: ?>
                        <li><a href="login.php" class="<?= ($current_page == 'login.php' ? 'active' : '') ?>"><i class="fas fa-sign-in-alt"></i> Login</a></li>
                        <li><a href="register.php" class="<?= ($current_page == 'register.php' ? 'active' : '') ?>"><i class="fas fa-user-plus"></i> Register</a></li>
                    <?php endif; ?>
                </ul>
                <!-- =========== END OF MENU AREA =========== -->

            </nav>
        </div>
    </header>
    <div class="container main-content-area" style="padding-top: 20px; padding-bottom: 20px;">
        <?php
        // Display session messages
        if (isset($_SESSION['message'])): ?>
            <div class="alert alert-<?= htmlspecialchars($_SESSION['message_type']) ?>">
                <?= htmlspecialchars($_SESSION['message']) ?>
            </div>
            <?php
            unset($_SESSION['message']);
            unset($_SESSION['message_type']);
        endif;
        ?>