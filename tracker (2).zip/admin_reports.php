<?php
require_once 'includes/header.php'; // This includes db.php and functions.php
requireLogin();

// Admin Access Check
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    $_SESSION['message'] = "Access Denied: You do not have administrative privileges to view this page.";
    $_SESSION['message_type'] = "danger";
    header("Location: index.php");
    exit();
}

// --- PHP logic to fetch data (No changes here) ---
$stmtUsers = $pdo->query("SELECT id, username FROM users ORDER BY username ASC");
$allUsers = $stmtUsers->fetchAll();
$selectedUserId = null;
$reportEntries = [];
$userHasEntries = false;
$selectedUsername = '';
$defaultEndDate = date('Y-m-d');
$defaultStartDate = date('Y-m-01');
$filterDateFrom = isset($_GET['date_from']) && !empty($_GET['date_from']) ? $_GET['date_from'] : $defaultStartDate;
$filterDateTo = isset($_GET['date_to']) && !empty($_GET['date_to']) ? $_GET['date_to'] : $defaultEndDate;

if (isset($_GET['user_id_selected']) && !empty($_GET['user_id_selected']) && is_numeric($_GET['user_id_selected'])) {
    $selectedUserId = (int)$_GET['user_id_selected'];
    $dFrom = DateTime::createFromFormat('Y-m-d', $filterDateFrom);
    if (!$dFrom || $dFrom->format('Y-m-d') !== $filterDateFrom) $filterDateFrom = $defaultStartDate;
    $dTo = DateTime::createFromFormat('Y-m-d', $filterDateTo);
    if (!$dTo || $dTo->format('Y-m-d') !== $filterDateTo) $filterDateTo = $defaultEndDate;
    $stmt = $pdo->prepare("SELECT te.*, u.username FROM time_entries te JOIN users u ON te.user_id = u.id WHERE te.user_id = :user_id AND te.entry_date BETWEEN :date_from AND :date_to ORDER BY te.entry_date DESC, te.start_time DESC");
    $stmt->execute(['user_id' => $selectedUserId, 'date_from' => $filterDateFrom, 'date_to' => $filterDateTo]);
    $reportEntries = $stmt->fetchAll();
    $userHasEntries = !empty($reportEntries);
    if($userHasEntries){
        $selectedUsername = $reportEntries[0]['username'];
    } else {
        $stmtUserOnly = $pdo->prepare("SELECT username FROM users WHERE id = ?");
        $stmtUserOnly->execute([$selectedUserId]);
        $user = $stmtUserOnly->fetch();
        if($user) $selectedUsername = $user['username'];
    }
}
?>

<!-- =================================================================== -->
<!-- === NEW CSS FOR THE REDESIGNED FILTER CARD ======================== -->
<!-- =================================================================== -->
<style>
    .filter-card {
        background-color: #ffffff;
        border-radius: 12px;
        margin-bottom: 30px;
        border: 1px solid #e9ecef;
        box-shadow: 0 4px 12px rgba(0,0,0,0.05);
    }
    .filter-card .card-header {
        padding: 15px 25px;
        border-bottom: 1px solid #e9ecef;
        background-color: #f8f9fa;
        border-radius: 12px 12px 0 0;
    }
    .filter-card .card-header h3 {
        margin: 0;
        font-size: 1.25rem;
        font-weight: 600;
        color: var(--header-logo-color, #2D5A95);
        display: flex;
        align-items: center;
        gap: 10px;
    }
    .filter-form {
        display: grid;
        /* Responsive grid that adapts to screen size */
        grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
        gap: 20px;
        align-items: end; /* Aligns all items to the bottom, looks neat */
        padding: 25px;
    }
    .form-field {
        display: flex;
        flex-direction: column;
    }
    .form-field label {
        font-weight: 500;
        margin-bottom: 8px;
        font-size: 0.9rem;
        color: #495057;
    }
    .form-field select,
    .form-field input[type="date"] {
        padding: 12px;
        border: 1px solid #ced4da;
        border-radius: 6px;
        font-size: 1rem;
        background-color: #fff;
        transition: border-color 0.2s, box-shadow 0.2s;
    }
    .form-field select:focus,
    .form-field input[type="date"]:focus {
        border-color: #80bdff;
        box-shadow: 0 0 0 0.2rem rgba(0,123,255,.25);
        outline: none;
    }
    /* Specific styling for the action button's container */
    .form-field-action .button {
        width: 100%;
        padding-top: 12px;
        padding-bottom: 12px;
        font-weight: 500;
    }
</style>
<!-- =================================================================== -->
<!-- === END OF CSS BLOCK ============================================== -->
<!-- =================================================================== -->


<h1><i class="fas fa-user-shield"></i> Admin - User Reports</h1>

<!-- =================================================================== -->
<!-- === REDESIGNED FILTER SECTION ===================================== -->
<!-- =================================================================== -->
<div class="filter-card">
    <div class="card-header">
        <h3><i class="fas fa-filter"></i> Filter Report Data</h3>
    </div>
    
    <form method="GET" action="admin_reports.php" class="filter-form">
        <div class="form-field">
            <label for="user_id_selected">Select User:</label>
            <select name="user_id_selected" id="user_id_selected" required>
                <option value="">-- Choose a user --</option>
                <?php foreach ($allUsers as $user): ?>
                    <option value="<?= $user['id'] ?>" <?= ($selectedUserId == $user['id'] ? 'selected' : '') ?>>
                        <?= htmlspecialchars($user['username']) ?> (ID: <?= $user['id'] ?>)
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        
        <div class="form-field">
            <label for="date_from_admin">From Date:</label>
            <input type="date" name="date_from" id="date_from_admin" value="<?= htmlspecialchars($filterDateFrom) ?>">
        </div>
        
        <div class="form-field">
            <label for="date_to_admin">To Date:</label>
            <input type="date" name="date_to" id="date_to_admin" value="<?= htmlspecialchars($filterDateTo) ?>">
        </div>
        
        <div class="form-field-action">
             <button type="submit" class="button button-primary"><i class="fas fa-search"></i> View Report</button>
        </div>
    </form>
</div>
<!-- =================================================================== -->
<!-- === END OF REDESIGNED FILTER SECTION ============================== -->
<!-- =================================================================== -->


<?php if ($selectedUserId): // Only show report section if a user is selected ?>
    <?php if (!$userHasEntries && !empty($selectedUsername)): ?>
        <div class="alert alert-info" style="margin-top: 20px;"><i class="fas fa-info-circle"></i> No time entries found for <strong><?= htmlspecialchars($selectedUsername) ?></strong> for the selected period.</div>
    <?php elseif (!$userHasEntries && empty($selectedUsername) && $selectedUserId != ''): ?>
         <div class="alert alert-warning" style="margin-top:20px;"><i class="fas fa-exclamation-triangle"></i> Selected user (ID: <?= htmlspecialchars($selectedUserId)?>) not found or no entries for the period.</div>
    <?php elseif ($userHasEntries): ?>
        <div class="card" style="margin-top: 20px;">
            <div class="card-header" style="display:flex; justify-content:space-between; align-items:center; border-bottom: 1px solid #eee; padding-bottom:10px; margin-bottom:15px;">
                <h3>Report for: <?= htmlspecialchars($selectedUsername) ?></h3>
                <span style="font-size:0.9em; color:#555;">(<?= htmlspecialchars($filterDateFrom) ?> to <?= htmlspecialchars($filterDateTo) ?>)</span>
            </div>
            <div style="margin-bottom: 15px; padding-top:10px;">
                <form action="actions/download_report.php" method="POST" style="display:inline-block; margin-right:10px;">
                    <input type="hidden" name="target_user_id" value="<?= $selectedUserId ?>">
                    <input type="hidden" name="date_from" value="<?= htmlspecialchars($filterDateFrom) ?>">
                    <input type="hidden" name="date_to" value="<?= htmlspecialchars($filterDateTo) ?>">
                    <input type="hidden" name="format" value="csv">
                    <button type="submit" class="button" style="background-color: #198754; color: white;"><i class="fas fa-file-csv"></i> Download as CSV</button>
                </form>
                <form action="actions/download_report.php" method="POST" style="display:inline-block;">
                    <input type="hidden" name="target_user_id" value="<?= $selectedUserId ?>">
                    <input type="hidden" name="date_from" value="<?= htmlspecialchars($filterDateFrom) ?>">
                    <input type="hidden" name="date_to" value="<?= htmlspecialchars($filterDateTo) ?>">
                    <input type="hidden" name="format" value="pdf">
                    <button type="submit" class="button" style="background-color: #dc3545; color: white;"><i class="fas fa-file-pdf"></i> Download as PDF</button>
                </form>
            </div>

            <table class="reports-table">
                <!-- ... The rest of your results table remains exactly the same ... -->
                <thead>
                    <tr>
                        <th>Entry ID</th>
                        <th>Date</th>
                        <th>Task Name</th>
                        <th>Start Time</th>
                        <th>End Time</th>
                        <th>Duration</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $grandTotalSeconds = 0;
                    foreach ($reportEntries as $entry):
                        $durationStr = "Ongoing";
                        $currentEntrySeconds = 0;
                        if ($entry['end_time']) {
                            try {
                                $start = new DateTime($entry['start_time']);
                                $end = new DateTime($entry['end_time']);
                                $interval = $start->diff($end);
                                $durationStr = $interval->format('%Hh %Im %Ss');
                                $currentEntrySeconds = ($end->getTimestamp() - $start->getTimestamp());
                                $grandTotalSeconds += $currentEntrySeconds;
                            } catch (Exception $e) {
                                $durationStr = "Error in duration";
                            }
                        } else {
                            $durationStr = formatDuration($entry['start_time'], null) . " (Active)";
                        }
                    ?>
                    <tr>
                        <td><?= $entry['id'] ?></td>
                        <td><?= htmlspecialchars(date('Y-m-d', strtotime($entry['entry_date']))) ?></td>
                        <td><?= htmlspecialchars($entry['task_name']) ?></td>
                        <td><?= date('H:i:s', strtotime($entry['start_time'])) ?></td>
                        <td><?= $entry['end_time'] ? date('H:i:s', strtotime($entry['end_time'])) : 'Active' ?></td>
                        <td><?= $durationStr ?></td>
                        <td style="white-space: nowrap;">
                            <a href="edit_entry.php?id=<?= $entry['id'] ?>" class="button-link button" style="font-size:0.8em; padding: 5px 8px; background-color: #0d6efd; color:white; margin-right: 5px; text-decoration:none;"><i class="fas fa-edit"></i> Edit</a>
                            <form action="actions/delete_entry.php" method="POST" style="display:inline-block;" onsubmit="return confirm('Are you sure you want to delete this time entry (ID: <?= $entry['id'] ?>)? This action cannot be undone.');">
                                <input type="hidden" name="entry_id" value="<?= $entry['id'] ?>">
                                <input type="hidden" name="user_id_selected" value="<?= $selectedUserId ?>">
                                <input type="hidden" name="date_from" value="<?= htmlspecialchars($filterDateFrom) ?>">
                                <input type="hidden" name="date_to" value="<?= htmlspecialchars($filterDateTo) ?>">
                                <button type="submit" class="button" style="font-size:0.8em; padding: 5px 8px; background-color: #dc3545; color:white;"><i class="fas fa-trash-alt"></i> Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
                <?php if ($grandTotalSeconds > 0 || count($reportEntries) > 0) : ?>
                <tfoot>
                    <tr>
                        <td colspan="5" style="text-align:right; font-weight:bold;">Total Logged Time for Period:</td>
                        <td style="font-weight:bold;">
                            <?php
                                $hours = floor($grandTotalSeconds / 3600);
                                $minutes = floor(($grandTotalSeconds % 3600) / 60);
                                $seconds = $grandTotalSeconds % 60;
                                echo sprintf('%02dh %02dm %02ds', $hours, $minutes, $seconds);
                            ?>
                        </td>
                        <td></td>
                    </tr>
                </tfoot>
                <?php endif; ?>
            </table>
        </div>
    <?php endif; ?>
<?php else: ?>
    <div class="alert alert-info" style="margin-top:20px;"><i class="fas fa-info-circle"></i> Please select a user and date range to view their report.</div>
<?php endif; ?>

<?php require_once 'includes/footer.php'; ?>