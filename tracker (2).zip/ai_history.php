<?php
require_once 'includes/header.php';
requireLogin();

$userId = $_SESSION['user_id'];

// Fetch AI history for the logged-in user, most recent first
$stmt = $pdo->prepare("SELECT * FROM ai_logs WHERE user_id = ? ORDER BY generated_at DESC");
$stmt->execute([$userId]);
$logs = $stmt->fetchAll();
?>

<!-- =================================================================== -->
<!-- === NEW CSS FOR THE REDESIGNED AI HISTORY PAGE ==================== -->
<!-- =================================================================== -->
<style>
    :root { --dark-navy: #0b1a2e; --light-navy: #112240; --accent-green: #64ffda; --light-grey: #ccd6f6; --mid-grey: #8892b0; }
    @keyframes fadeInUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }

    /* --- Page & Theme Overrides --- */
    body { background-color: var(--dark-navy); color: var(--light-grey); }
    .main-content-area { background-color: transparent !important; box-shadow: none !important; padding: 0 !important; max-width: 1100px !important; }
    .site-header { background-color: var(--light-navy) !important; box-shadow: none !important; border-bottom: 1px solid #ffffff1a !important; }
    .site-header a, .site-header .current-time { color: var(--light-grey) !important; } .site-header a.active { background-color: var(--accent-green) !important; color: var(--dark-navy) !important; } .site-header a.active i { color: var(--dark-navy) !important; }
    .site-footer-container { display: none; }

    .ai-history-container { padding: 20px; animation: fadeInUp 0.5s ease-out; }
    .ai-history-container h1 { font-size: 2.5rem; font-weight: 600; color: #fff; margin-bottom: 10px; }
    .ai-history-container p { color: var(--mid-grey); font-size: 1.1rem; margin-bottom: 30px; }
    
    .history-item {
        background-color: var(--light-navy);
        border: 1px solid #ffffff1a;
        border-radius: 12px;
        margin-bottom: 15px;
        overflow: hidden; /* Important for the animation */
    }
    .history-summary {
        padding: 20px 25px;
        cursor: pointer;
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-weight: 500;
        transition: background-color 0.3s ease;
    }
    .history-summary:hover { background-color: rgba(100, 255, 218, 0.05); }
    .summary-icon { font-size: 1.2rem; color: var(--accent-green); transition: transform 0.4s cubic-bezier(0.25, 1, 0.5, 1); }
    
    .history-details {
        max-height: 0;
        overflow: hidden;
        transition: max-height 0.5s cubic-bezier(0.25, 1, 0.5, 1), padding 0.5s cubic-bezier(0.25, 1, 0.5, 1);
        padding: 0 25px;
    }
    .history-item.active .history-summary .summary-icon { transform: rotate(180deg); }
    .history-item.active .history-details {
        max-height: 1200px; /* Large enough for content */
        padding: 25px;
        padding-top: 0;
        border-top: 1px solid #ffffff1a;
    }

    .details-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 25px;
        margin-top: 20px;
    }
    .details-box { background-color: var(--dark-navy); border-radius: 8px; padding: 20px; }
    .details-box h4 { margin-top: 0; color: var(--accent-green); }
    
    /* This is the key for scrolling long content */
    .scrollable-content {
        max-height: 400px;
        overflow-y: auto;
        padding-right: 10px; /* Space for scrollbar */
        font-family: monospace;
        font-size: 0.9rem;
    }
    .scrollable-content pre { white-space: pre-wrap; word-wrap: break-word; }
    .response-preview { font-family: 'Poppins', sans-serif; font-size: 1rem; }

    @media (max-width: 768px) {
        .details-grid { grid-template-columns: 1fr; }
    }
</style>
<!-- =================================================================== -->
<!-- === END OF CSS BLOCK ============================================== -->
<!-- =================================================================== -->

<div class="ai-history-container">
    <h1><i class="fas fa-robot"></i> AI Response History</h1>
    <p>A log of your interactions with the content generation AI.</p>

    <div style="margin-top: 30px;">
        <?php if (empty($logs)): ?>
            <div class="alert alert-info" style="background-color: var(--light-navy); border: 1px solid var(--accent-green); color: var(--accent-green);">You have not generated any content with the AI yet.</div>
        <?php else: ?>
            <?php foreach ($logs as $log): ?>
                <div class="history-item">
                    <!-- AFTER (The corrected line) -->
                    <div class="history-summary">
                        <span>Generated on: <?=
                            // Create a DateTime object from the UTC timestamp and convert it to Indian Standard Time
                            (new DateTime($log['generated_at'], new DateTimeZone('UTC')))
                            ->setTimezone(new DateTimeZone('Asia/Kolkata'))
                            ->format('F j, Y \a\t h:i A')
                        ?></span>
                        <i class="fas fa-chevron-down summary-icon"></i>
                    </div>
                    <div class="history-details">
                        <div class="details-grid">
                            <div class="details-box">
                                <h4>Prompt Sent to AI</h4>
                                <div class="scrollable-content">
                                    <pre><?= htmlspecialchars($log['prompt_text']) ?></pre>
                                </div>
                            </div>
                            <div class="details-box">
                                <h4>Response Received from AI</h4>
                                <div class="scrollable-content response-preview">
                                    <?= $log['response_text'] // Display raw HTML response ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const historyItems = document.querySelectorAll('.history-item');
    historyItems.forEach(item => {
        const summary = item.querySelector('.history-summary');
        summary.addEventListener('click', () => {
            // This allows only one item to be open at a time for a cleaner look
            historyItems.forEach(otherItem => {
                if (otherItem !== item) {
                    otherItem.classList.remove('active');
                }
            });
            item.classList.toggle('active');
        });
    });
});
</script>

<?php require_once 'includes/footer.php'; ?>