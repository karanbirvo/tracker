<?php
require_once 'includes/header.php';
requireLogin();

// PHP now only fetches the FIRST page of results.
$items_per_page = 15;
$stmt = $pdo->prepare("SELECT * FROM email_logs WHERE user_id = :user_id ORDER BY sent_at DESC LIMIT :limit");
$stmt->bindValue(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
$stmt->bindValue(':limit', $items_per_page, PDO::PARAM_INT);
$stmt->execute();
$initial_logs = $stmt->fetchAll();
?>

<!-- === CSS FOR THE MODAL (POPUP) - No changes needed === -->
<style>
    .modal-backdrop { display: none; position: fixed; z-index: 1050; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0,0,0,0.6); animation: fadeIn 0.3s; }
    .modal-content-area { background-color: #fefefe; margin: 5% auto; padding: 25px; border: 1px solid #888; width: 80%; max-width: 800px; border-radius: 8px; position: relative; box-shadow: 0 5px 15px rgba(0,0,0,0.3); animation: slideIn 0.3s; }
    .modal-close-btn { color: #aaa; position: absolute; top: 10px; right: 20px; font-size: 28px; font-weight: bold; transition: color 0.2s; }
    .modal-close-btn:hover, .modal-close-btn:focus { color: black; text-decoration: none; cursor: pointer; }
    .modal-body { max-height: 60vh; overflow-y: auto; padding-right: 15px; }
    @keyframes fadeIn { from {opacity: 0;} to {opacity: 1;} }
    @keyframes slideIn { from {transform: translateY(-50px);} to {transform: translateY(0);} }
</style>

<h1><i class="fas fa-history"></i> My Sent Email History</h1>

<div class="card" style="margin-top: 20px;">
    <?php if (empty($initial_logs)): ?>
        <p class="alert alert-info">You have not sent any emails yet.</p>
    <?php else: ?>
        <table class="reports-table" id="history-table">
            <thead>
                <tr>
                    <th>Date & Time</th>
                    <th>To</th>
                    <th>Subject</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <!-- The table body now has an ID for easy access with JavaScript -->
            <tbody id="history-table-body">
                <?php foreach ($initial_logs as $log): ?>
                <tr>
                    <td><?= htmlspecialchars(date('Y-m-d H:i:s', strtotime($log['sent_at']))) ?></td>
                    <td><?= htmlspecialchars($log['sent_to']) ?></td>
                    <td><?= htmlspecialchars($log['subject']) ?></td>
                    <td>
                        <?php if ($log['status'] === 'success'): ?> <span style="color: green; font-weight: bold;">Success</span> <?php else: ?> <span style="color: red; font-weight: bold;">Failed</span> <?php endif; ?>
                    </td>
                    <td>
                        <button class="button-link view-details-btn" 
                                data-to="<?= htmlspecialchars($log['sent_to']) ?>"
                                data-from="<?= htmlspecialchars($log['sent_from']) ?>"
                                data-subject="<?= htmlspecialchars($log['subject']) ?>"
                                data-attachments="<?= !empty($log['attachments']) ? htmlspecialchars($log['attachments']) : 'None' ?>"
                                data-error="<?= htmlspecialchars($log['error_message']) ?>">
                            <i class="fas fa-eye"></i> View Details
                        </button>
                        <div class="log-body-content" style="display: none;"><?= $log['body'] ?></div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        
        <!-- "Load More" Button Area -->
        <div id="load-more-container" style="text-align: center; padding: 20px;">
            <button id="load-more-btn" class="button">Load More</button>
        </div>

    <?php endif; ?>
</div>

<!-- === THE MODAL HTML STRUCTURE (Initially hidden) - No changes needed === -->
<div id="details-modal" class="modal-backdrop">
    <div class="modal-content-area">
        <span id="modal-close-btn" class="modal-close-btn">&times;</span>
        <h2 id="modal-subject">Email Details</h2>
        <hr>
        <div class="modal-body">
            <p><strong>From:</strong> <span id="modal-from"></span></p>
            <p><strong>To:</strong> <span id="modal-to"></span></p>
            <p><strong>Attachments:</strong> <span id="modal-attachments"></span></p>
            <div id="modal-error-section" style="display: none;">
                <p><strong>Error Message:</strong></p>
                <pre id="modal-error" style="color: red; white-space: pre-wrap; background: #f9f9f9; padding: 10px; border-radius: 4px;"></pre>
            </div>
            <hr>
            <h3>Email Body:</h3>
            <div id="modal-body-content" style="border: 1px solid #ddd; padding: 15px; border-radius: 4px; background: #fff;"></div>
        </div>
    </div>
</div>

<!-- === JAVASCRIPT FOR MODAL & "LOAD MORE" FUNCTIONALITY === -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // --- "LOAD MORE" LOGIC ---
    const loadMoreBtn = document.getElementById('load-more-btn');
    const tableBody = document.getElementById('history-table-body');
    const container = document.getElementById('load-more-container');
    let currentPage = 1;

    if (loadMoreBtn) {
        loadMoreBtn.addEventListener('click', function() {
            currentPage++; // Increment the page to fetch
            loadMoreBtn.disabled = true;
            loadMoreBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Loading...';

            // Fetch the next page of results from our new backend script
            fetch(`./actions/fetch_email_history.php?page=${currentPage}`)
                .then(response => response.text())
                .then(html => {
                    if (html.trim() !== '') {
                        // If we got results, append them to the table
                        tableBody.insertAdjacentHTML('beforeend', html);
                        loadMoreBtn.disabled = false;
                        loadMoreBtn.innerHTML = 'Load More';
                    } else {
                        // If the response is empty, there are no more results
                        container.innerHTML = '<p><em>No more entries to load.</em></p>';
                    }
                })
                .catch(error => {
                    console.error('Error fetching email history:', error);
                    container.innerHTML = '<p style="color: red;">Could not load more entries.</p>';
                });
        });
    }

    // --- MODAL LOGIC (with Event Delegation) ---
    const modal = document.getElementById('details-modal');
    const closeBtn = document.getElementById('modal-close-btn');
    const historyTable = document.getElementById('history-table');

    // Attach ONE click listener to the table. This is more efficient and
    // works for items that are loaded later via "Load More".
    if (historyTable) {
        historyTable.addEventListener('click', function(event) {
            // Check if the clicked element is a "View Details" button
            const button = event.target.closest('.view-details-btn');
            if (button) {
                const modalSubject = document.getElementById('modal-subject');
                const modalFrom = document.getElementById('modal-from');
                const modalTo = document.getElementById('modal-to');
                const modalAttachments = document.getElementById('modal-attachments');
                const modalErrorSection = document.getElementById('modal-error-section');
                const modalError = document.getElementById('modal-error');
                const modalBodyContent = document.getElementById('modal-body-content');
                
                const bodyHtml = button.closest('td').querySelector('.log-body-content').innerHTML;

                modalSubject.textContent = button.dataset.subject;
                modalFrom.textContent = button.dataset.from;
                modalTo.textContent = button.dataset.to;
                modalAttachments.textContent = button.dataset.attachments;
                modalBodyContent.innerHTML = bodyHtml;

                if (button.dataset.error) {
                    modalError.textContent = button.dataset.error;
                    modalErrorSection.style.display = 'block';
                } else {
                    modalErrorSection.style.display = 'none';
                }
                modal.style.display = 'block';
            }
        });
    }
    
    // Functions to close the modal (no changes needed here)
    function closeModal() { if(modal) modal.style.display = 'none'; }
    if (closeBtn) closeBtn.addEventListener('click', closeModal);
    if (modal) modal.addEventListener('click', function(event) { if (event.target === modal) closeModal(); });
    document.addEventListener('keydown', function(event) { if (event.key === "Escape" && modal && modal.style.display === 'block') closeModal(); });
});
</script>

<?php require_once 'includes/footer.php'; ?>