<?php
// --- STEP 1: All PHP processing logic comes FIRST, before any HTML ---
require_once 'includes/functions.php';
requireLogin();

$userId = $_SESSION['user_id'];
$profile_errors = [];
$password_errors = [];
$profile_success_message = '';
$password_success_message = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_profile'])) {
        $new_username = trim($_POST['username']); $new_email = trim($_POST['email']); $new_mobile = trim($_POST['mobile_number']);
        if (empty($new_username)) { $profile_errors[] = "Username cannot be empty."; }
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? AND id != ?"); $stmt->execute([$new_username, $userId]);
        if ($stmt->fetch()) { $profile_errors[] = "That username is already taken."; }
        if (!empty($new_email)) {
            if (!filter_var($new_email, FILTER_VALIDATE_EMAIL)) { $profile_errors[] = "Please enter a valid email address."; }
            else { $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? AND id != ?"); $stmt->execute([$new_email, $userId]); if ($stmt->fetch()) { $profile_errors[] = "That email address is already in use."; } }
        }
        if (empty($profile_errors)) {
            $stmt = $pdo->prepare("UPDATE users SET username = ?, email = ?, mobile_number = ? WHERE id = ?");
            $stmt->execute([$new_username, $new_email, $new_mobile, $userId]);
            $_SESSION['username'] = $new_username;
            $profile_success_message = "Your profile has been updated successfully.";
        }
    }
    if (isset($_POST['change_password'])) {
        $current_password = $_POST['current_password']; $new_password = $_POST['new_password']; $confirm_password = $_POST['confirm_password'];
        $stmt = $pdo->prepare("SELECT password_hash FROM users WHERE id = ?"); $stmt->execute([$userId]); $user = $stmt->fetch();
        if (empty($current_password) || !password_verify($current_password, $user['password_hash'])) { $password_errors[] = "Your current password is incorrect."; }
        if (strlen($new_password) < 6) { $password_errors[] = "New password must be at least 6 characters."; }
        if ($new_password !== $confirm_password) { $password_errors[] = "The new passwords do not match."; }
        if (empty($password_errors)) {
            $new_password_hash = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET password_hash = ? WHERE id = ?");
            $stmt->execute([$new_password_hash, $userId]);
            $password_success_message = "Your password has been changed successfully.";
        }
    }
}

// Fetch current user data to display in the form
$stmt = $pdo->prepare("SELECT username, email, mobile_number FROM users WHERE id = ?");
$stmt->execute([$userId]);
$user_data = $stmt->fetch();

// --- STEP 2: Now include the header ---
require_once 'includes/header.php';
?>

<!-- =================================================================== -->
<!-- === NEW CSS FOR THE ANIMATED & REDESIGNED PROFILE PAGE ============ -->
<!-- =================================================================== -->
<style>
    @keyframes fadeInUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }

    .profile-page-container {
        max-width: 900px;
        margin: 20px auto;
        animation: fadeInUp 0.5s ease-out;
    }

    .profile-header {
        background: linear-gradient(135deg, #2D5A95, #4A8AEC);
        color: #fff;
        padding: 30px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        gap: 20px;
        box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        margin-bottom: 30px;
    }
    .profile-header .icon { font-size: 4rem; }
    .profile-header h1 {
    margin: 0;
    font-size: 2.2rem;
    font-weight: 600;
    color: white;
}
button#password-tab-btn:hover {
    background-color: #000000;
    color: white;
}
button#profile-tab-btn:hover {
    color: white;
    background-color: black;
}
    .profile-header p { margin: 5px 0 0; opacity: 0.8; }

    .profile-tabs {
        display: flex;
        border-bottom: 1px solid #dee2e6;
        margin-bottom: 30px;
    }
    .tab-btn {
        background: none;
        border: none;
        padding: 15px 25px;
        cursor: pointer;
        font-size: 1.1rem;
        font-weight: 500;
        color: #6c757d;
        position: relative;
        transition: color 0.3s ease;
    }
    .tab-btn::after {
        content: '';
        position: absolute;
        bottom: -1px;
        left: 0;
        width: 0;
        height: 3px;
        background-color: var(--header-logo-color, #2D5A95);
        transition: width 0.3s ease;
    }
    .form-group input[type="text"], .form-group input[type="password"], .form-group input[type="email"] {
    padding-left: 40px;
}
    .tab-btn.active { color: var(--header-logo-color, #2D5A95); }
    .tab-btn.active::after { width: 100%; }

    .profile-tab-content { display: none; }
    .profile-tab-content.active { display: block; }
    
    .profile-card { background-color: #ffffff; border-radius: 12px; padding: 30px; }
    .profile-card h3 { font-size: 1.5rem; font-weight: 600; margin-bottom: 25px; color: #343a40; }

    .input-group { position: relative; margin-bottom: 25px; }
    .input-group-icon { position: absolute; top: 50%; left: 15px; transform: translateY(-50%); color: #adb5bd; }
    .input-group input { padding-left: 45px; height: 50px; width: 100%; box-sizing: border-box; transition: all 0.2s ease; }
    .input-group input:focus { border-color: #80bdff; box-shadow: 0 0 0 0.2rem rgba(0,123,255,.25); }

    .button { transition: all 0.3s ease; }
    .button:hover { transform: translateY(-2px); box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
</style>
<!-- =================================================================== -->
<!-- === END OF CSS BLOCK ============================================== -->
<!-- =================================================================== -->

<div class="profile-page-container">

    <div class="profile-header">
        <i class="fas fa-user-circle icon"></i>
        <div>
            <h1><?= htmlspecialchars($user_data['username']) ?></h1>
            <p><?= htmlspecialchars($user_data['email'] ?? 'No email set') ?></p>
        </div>
    </div>

    <div class="profile-tabs">
        <button id="profile-tab-btn" class="tab-btn active" data-tab="profile-content"><i class="fas fa-id-card"></i> Profile Details</button>
        <button id="password-tab-btn" class="tab-btn" data-tab="password-content"><i class="fas fa-key"></i> Change Password</button>
    </div>

    <div class="profile-card">
        <!-- Section 1: Update Profile Information -->
        <div id="profile-content" class="profile-tab-content active">
            <h3>Edit Your Personal Information</h3>
            <?php if (!empty($profile_errors)): ?><div class="alert alert-danger"><?php foreach ($profile_errors as $error) echo "<p class='mb-0'>".htmlspecialchars($error)."</p>"; ?></div><?php endif; ?>
            <?php if (!empty($profile_success_message)): ?><div class="alert alert-success"><p class="mb-0"><?= htmlspecialchars($profile_success_message) ?></p></div><?php endif; ?>
            
            <form action="profile.php" method="POST">
                <div class="form-group"><label for="username">Username</label><div class="input-group"><i class="fas fa-user input-group-icon"></i><input type="text" id="username" name="username" value="<?= htmlspecialchars($user_data['username']) ?>" required></div></div>
                <div class="form-group"><label for="email">Email Address</label><div class="input-group"><i class="fas fa-envelope input-group-icon"></i><input type="email" id="email" name="email" value="<?= htmlspecialchars($user_data['email'] ?? '') ?>"></div></div>
                <div class="form-group"><label for="mobile_number">Mobile Number</label><div class="input-group"><i class="fas fa-mobile-alt input-group-icon"></i><input type="tel" id="mobile_number" name="mobile_number" value="<?= htmlspecialchars($user_data['mobile_number'] ?? '') ?>"></div></div>
                <button type="submit" name="update_profile" class="button button-primary"><i class="fas fa-save"></i> Save Profile Changes</button>
            </form>
        </div>

        <!-- Section 2: Change Password -->
        <div id="password-content" class="profile-tab-content">
            <h3>Update Your Security Settings</h3>
            <?php if (!empty($password_errors)): ?><div class="alert alert-danger"><?php foreach ($password_errors as $error) echo "<p class='mb-0'>".htmlspecialchars($error)."</p>"; ?></div><?php endif; ?>
            <?php if (!empty($password_success_message)): ?><div class="alert alert-success"><p class="mb-0"><?= htmlspecialchars($password_success_message) ?></p></div><?php endif; ?>
            
            <form action="profile.php" method="POST">
                <div class="form-group"><label for="current_password">Current Password</label><div class="input-group"><i class="fas fa-lock input-group-icon"></i><input type="password" id="current_password" name="current_password" required></div></div>
                <div class="form-group"><label for="new_password">New Password</label><div class="input-group"><i class="fas fa-lock-open input-group-icon"></i><input type="password" id="new_password" name="new_password" required></div></div>
                <div class="form-group"><label for="confirm_password">Confirm New Password</label><div class="input-group"><i class="fas fa-lock-open input-group-icon"></i><input type="password" id="confirm_password" name="confirm_password" required></div></div>
                <button type="submit" name="change_password" class="button"><i class="fas fa-sync-alt"></i> Change Password</button>
            </form>
        </div>
    </div>
</div>

<!-- =================================================================== -->
<!-- === JAVASCRIPT FOR TAB FUNCTIONALITY ============================== -->
<!-- =================================================================== -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const tabs = document.querySelectorAll('.tab-btn');
    const contents = document.querySelectorAll('.profile-tab-content');

    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            // Deactivate all tabs and content
            tabs.forEach(item => item.classList.remove('active'));
            contents.forEach(item => item.classList.remove('active'));

            // Activate the clicked tab and corresponding content
            const target = document.getElementById(tab.dataset.tab);
            tab.classList.add('active');
            target.classList.add('active');
        });
    });

    // Logic to automatically switch to the correct tab if there was a server-side error
    <?php if (!empty($password_errors)): ?>
        document.getElementById('password-tab-btn').click();
    <?php elseif (!empty($profile_errors)): ?>
        document.getElementById('profile-tab-btn').click();
    <?php endif; ?>
});
</script>
<!-- =================================================================== -->
<!-- === END OF JAVASCRIPT BLOCK ======================================= -->
<!-- =================================================================== -->

<?php require_once 'includes/footer.php'; ?>